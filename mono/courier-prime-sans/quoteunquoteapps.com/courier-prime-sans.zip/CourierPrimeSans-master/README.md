# Courier Prime Sans

Courier Prime Sans is the sans serif version of [Courier Prime](https://github.com/quoteunquoteapps/CourierPrime). It was designed by Alan Dague-Greene for John August and released as 'Highland Sans' with [Highland](http://quoteunquoteapps.com/highland/) by Quote-Unquote Apps.

## Related repositories

- [Courier Prime](https://github.com/quoteunquoteapps/CourierPrime)
- [Courier Prime Source](https://github.com/quoteunquoteapps/CourierPrimeSource)
